﻿using System;
// Додайте цей простір імен, якщо ви використовуєте тип Guid або DateTime

// --- БАЗОВИЙ КЛАС 1: LibraryItem (Бібліотечний елемент) ---
// Успадковується класами Book та Magazine
public class LibraryItem
{
    // Властивість 1: Унікальний ідентифікатор (Guid)
    public Guid Id { get; set; }

    // Властивість 2: Назва/Заголовок елемента
    public string Title { get; set; }

    // Властивість 3: Рік видання
    public int YearPublished { get; set; }
}

// --- КЛАС-СПАДКОЄМЕЦЬ 1: Book (Книга) ---
// Успадковується від LibraryItem
public class Book : LibraryItem
{
    // Властивість 1: Автор книги
    public string Author { get; set; }

    // Властивість 2: Міжнародний стандартний номер книги
    public string ISBN { get; set; }

    // Властивість 3: Кількість сторінок
    public int NumberOfPages { get; set; }
}

// --- КЛАС-СПАДКОЄМЕЦЬ 2: Magazine (Журнал) ---
// Успадковується від LibraryItem
public class Magazine : LibraryItem
{
    // Властивість 1: Номер випуску
    public int IssueNumber { get; set; }

    // Властивість 2: Видавець (наприклад, "Vogue" або "National Geographic")
    public string Publisher { get; set; }

    // Властивість 3: Категорія або тематика
    public string Category { get; set; }
}


// --- БАЗОВИЙ КЛАС 2: Person (Особа) ---
// Успадковується класом Librarian
public class Person
{
    // Властивість 1: Унікальний ідентифікатор особи
    public Guid PersonId { get; set; }

    // Властивість 2: Ім'я
    public string FirstName { get; set; }

    // Властивість 3: Прізвище
    public string LastName { get; set; }
}

// --- КЛАС-СПАДКОЄМЕЦЬ 3: Librarian (Бібліотекар) ---
// Успадковується від Person
public class Librarian : Person
{
    // Властивість 1: Ідентифікатор співробітника
    public int EmployeeId { get; set; }

    // Властивість 2: Відділ (наприклад, "Обслуговування", "Архіви")
    public string Department { get; set; }

    // Властивість 3: Дата найму на роботу
    public DateTime DateHired { get; set; }
}